browser.browserAction.onClicked.addListener((tab) => {
    console.log('Extension clicked');
    browser.tabs.executeScript(tab.id, {
      file: 'content.js'
    });
  });
  