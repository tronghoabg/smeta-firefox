document.getElementById('clickMe').addEventListener('click', () => {
    alert('Button clicked!');
  });
  